# Confirmed USB HID descriptor and report-path changes

These are reconstructions from the five firmware binaries, not vendor release notes. All offsets are payload-relative; add `0x1000` for container offsets. The descriptor interpretation follows the [USB HID specification](https://usb.org/document-library/device-class-definition-hid-111). The decoded items and bytes are retained in `usb-descriptors-decoded.json` and independently checked in `../symbols/hid-descriptor-review.json`.

| Version | Shared descriptor offset | Shared descriptor length | Report 1 input data | Report 1 LED output |
| --- | --- | ---: | ---: | --- |
| 0.0.5.0 | `0x195D4` | 125 bytes | 120 bits / 15 bytes | absent |
| 0.0.6.0 | `0x19660` | 125 bytes | 120 bits / 15 bytes | absent |
| 0.0.7.0 | `0x197E0` | 125 bytes | 120 bits / 15 bytes | absent |
| 0.0.8.0 | `0x19CA0` | 145 bytes | 120 bits / 15 bytes | 3 LED bits + 5 padding bits |
| 0.1.0.0 | `0x19EA4` | 157 bytes | 128 bits / 16 bytes | 3 LED bits + 5 padding bits |

The lengths above are the full shared keyboard/consumer/system/mouse descriptor, not just its keyboard collection. Report data lengths exclude the report ID. Including ID 1, the input report changes from 16 bytes to 17 bytes in v0.1.0.0.

## v0.0.7.0 to v0.0.8.0

The keyboard collection of shared Report ID 1 gains an LED usage-page output field: usages 1 through 3, three 1-bit data fields followed by five constant padding bits. These are the Num Lock, Caps Lock and Scroll Lock LED usages. Older firmware already had LED output fields in its separate boot-keyboard descriptor. This change adds LED output support to the shared/NKRO collection; it is not evidence that the keyboard previously lacked all lock-LED support.

The input shape remains 120 bits in this transition. The separate boot-keyboard descriptor, vendor WebHID descriptor, and device descriptor remain byte-identical across all five original images. The device descriptor still reports VID/PID `1CA6:300A` and `bcdDevice=0002` even though application firmware versions change.

## v0.0.8.0 to v0.1.0.0

The shared keyboard input field is made explicit:

- 109 one-bit key states for usage IDs `0x04` through `0x70`.
- 11 constant padding bits, bringing that part to 120 bits.
- Eight one-bit modifier states for usage IDs `0xE0` through `0xE7`.

The prior descriptor declared 120 data bits against usages `0x04..0x70` and did not declare modifier fields in that collection. The new description totals 128 bits and explicitly represents the modifier keys. This proves a protocol/layout change; it does not alone prove a particular game or operating-system bug was fixed.

The report-construction/send path also changes. In the matching native region at v0.0.8.0 payload `0x5342` and v0.1.0.0 payload `0x53F4`, the latest path incorporates a separate modifier byte, compares a 17-byte buffer against a retained prior-report buffer, suppresses the unchanged report in that path, and copies the sent buffer for the next comparison. Its reset helper grows its keyboard-buffer clearing length from 15 to 16 data bytes. These are code observations; interrupt scheduling and measured USB traffic were not tested.

## v0.0.6.0 to v0.0.7.0 report-builder rewrite

The ordinary-key branch in the report builder at v0.0.7.0 payload `0x48BE` computes `(usage - 4) & 0xFF` and only proceeds into its bitmap update when that value is at most `0x6C` (108), corresponding to usage IDs `0x04..0x70`. It tests the target bit before setting it and separately fills available boot-report key slots. The prior matching routine at `0x48A4` has a different traversal/update structure without this same explicit bound in its ordinary-key branch. Thus report-building logic changed, including explicit bitmap bounds and duplicate-bit handling. It is not presented as a complete proof that every invalid input path was unsafe in the older firmware.

## Scope

These findings cover descriptor bytes and localized, statically decoded report paths. They are not a complete reverse engineering of ADC scanning, rapid-trigger behavior, macros, RGB, or all task/interrupt interactions. The candidate-region diffs are navigation aids and do not count relocation-only differences as proven new features.
