# Inputs still required for the AE64 board port

This checklist describes missing engineering work, not a completed or flashable port.

| Area | Required implementation / evidence |
| --- | --- |
| Exact silicon | Package marking, ID/register read, revision, pin count, confirmed manual. HPM5300 family is strongly inferred only. |
| SDK/toolchain | Pinned SDK and compiler commits/versions, instruction/ABI compatibility, dependencies and reproducible build log. |
| Memory/linker | Application VMA, physical flash partition, writable capacity, bootloader/config/calibration boundaries, startup copy/zero tables, vectors, ILM/DLM, stack/heap and TLS. |
| Startup | Compatible reset path, gp/tp/sp initialization, cache control, vector relocation, exceptions, hardware interrupts. |
| Clocks | Measured crystal/internal oscillator source, PLL/dividers, USB reference, scan clock and actual core frequency. |
| USB | Correct controller/IP revision, pins/PHY setup, IRQ, descriptors, keyboard reports, polling/endpoint behavior, unplug/suspend/wakeup handling. |
| Hall scanning | ADC channel and mux mapping, scan synchronization, direct-channel mapping, sample timing/filtering, invalid-frame handling and raw range measurements. |
| Calibration | Per-key calibration model/storage layout, backups, polarity, travel conversion, data migration and wear-safe persistence. |
| Physical layout | Logical-index to physical-key to HID usage mapping, layers and boot key behavior. |
| RGB | Measured LED topology/data pins, power limits and timing; leave disabled during USB/scan bring-up. |
| Recovery | Independently demonstrated ROM/bootloader/debug access even when app USB fails; full flash backup if supported. |
| Package/flash | Container header/CRC, loader accept/reject behavior, write offsets, validation, reset, read-back/version check. |

The included `key_logic.c` is new fixed-threshold hysteresis example code using normalized travel. It is not the vendor's rapid-trigger algorithm, calibration implementation, scan driver or complete keyboard firmware.
