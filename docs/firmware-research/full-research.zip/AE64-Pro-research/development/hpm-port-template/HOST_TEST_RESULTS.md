# Validation results

Run on October 28, 2026 with the parent's locally staged, SHA-256-verified official Zig 0.17.0 archive. No installation, board build, device execution or firmware write was performed by this subtask.

## Host C behavior tests: PASS

Command from the template directory (substitute the compiler's actual path):

```powershell
python host-tests/run_host_tests.py --compiler C:\tools\zig\zig.exe --compiler-arg cc --build-dir build-host
```

The runner uses C11, `-O2 -Wall -Wextra -Werror -pedantic`. Test assertions are explicitly enabled even if the compiler's release mode defines `NDEBUG`.

Output:

```text
PASS: thresholds, hysteresis/noise, independent keys, full travel sweep, invalid input, saturation
```

An initial strict build caught release-mode assertion removal; the test source was corrected to undefine `NDEBUG` before including `assert.h`, then rebuilt and run successfully. This prevents an empty assertion suite from being reported as a pass.

## Isolated freestanding RV32 module: PASS

Command from the template directory:

```powershell
C:\tools\zig\zig.exe cc -target riscv32-freestanding -mcpu=generic_rv32+a+c+m -mabi=ilp32 -Os -ffreestanding -fno-builtin -std=c11 -Wall -Wextra -Werror -pedantic -I include -c src/key_logic.c -o build-host/key_logic.rv32.o
```

The object header was independently parsed: ELF32, little-endian, relocatable type 1, machine 243 (RISC-V), flags `0x1` (compressed instructions enabled, soft-float ABI). It contains the architecture attribute `rv32i2p1_m2p0_a2p1_c2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0`. See `rv32-compile-evidence.json` for hash and size.

Zig 0.17.0's `cc` front-end rejected `-march=rv32imac` as an unknown CPU. The accepted Zig-specific CPU/feature spelling above was used instead. The actual HPM GCC firmware project retains the GCC `RV_ARCH` / `RV_ABI` settings; this isolated compile does not validate HPM SDK integration.

Only `key_logic.c` was cross-compiled. The resulting object was kept in the task's work directory and is not distributed as a firmware image. It has no startup, linker map, vector table, USB/ADC implementation, board support or container header. The target keyboard project remains an unfinished port.
