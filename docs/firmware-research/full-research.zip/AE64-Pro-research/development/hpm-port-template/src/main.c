/* Application skeleton only: board_port.c is intentionally absent. SPDX-License-Identifier: MIT */
#include "board_port.h"
static struct ae64_key_state state[AE64_LOGICAL_KEY_COUNT];
static struct ae64_key_config config[AE64_LOGICAL_KEY_COUNT];
static uint16_t travel[AE64_LOGICAL_KEY_COUNT];
int main(void)
{
    if (!port_init() || !port_load_key_configs(config)) {
        port_fault();
        for (;;) { }
    }
    for (unsigned i=0; i<AE64_LOGICAL_KEY_COUNT; ++i) {
        if (!ae64_key_config_valid(&config[i])) {
            port_fault();
            for (;;) { }
        }
    }
    for (;;) {
        port_usb_service();
        if (!port_read_calibrated_frame(travel)) continue;
        bool changed=false;
        for (unsigned i=0; i<AE64_LOGICAL_KEY_COUNT; ++i) {
            changed |= ae64_key_update(&state[i], &config[i], travel[i]) != AE64_NO_CHANGE;
        }
        if (changed) port_publish_keys(state);
    }
}
