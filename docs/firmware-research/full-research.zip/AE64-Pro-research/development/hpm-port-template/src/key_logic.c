/* New example logic, not decompiled vendor firmware. SPDX-License-Identifier: MIT */
#include "key_logic.h"
bool ae64_key_config_valid(const struct ae64_key_config *config)
{
    return config && config->press <= AE64_TRAVEL_MAX &&
        config->press > config->release;
}
enum ae64_key_event ae64_key_update(struct ae64_key_state *state,
    const struct ae64_key_config *config, uint16_t calibrated_travel)
{
    if (!state || !ae64_key_config_valid(config)) return AE64_NO_CHANGE;
    if (calibrated_travel > AE64_TRAVEL_MAX) calibrated_travel = AE64_TRAVEL_MAX;
    if (!state->pressed && calibrated_travel >= config->press) {
        state->pressed = true;
        return AE64_PRESSED;
    }
    if (state->pressed && calibrated_travel <= config->release) {
        state->pressed = false;
        return AE64_RELEASED;
    }
    return AE64_NO_CHANGE;
}
