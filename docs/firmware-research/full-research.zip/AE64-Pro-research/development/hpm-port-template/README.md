# AE64 Pro custom-firmware development scaffold

**Status: unfinished board port. This project does not yet build a working or flashable keyboard image.** It provides a new portable C key-processing module, a board abstraction to implement, and a documented HPM SDK build/package sequence. The CMake configuration stops until the board port is explicitly completed. No programmer or HID transport is included here.

The code is new example code, not recovered vendor source. It demonstrates fixed-threshold hysteresis on normalized calibrated travel. It does not implement the vendor's rapid trigger, ADC scan map, calibration model, USB stack, RGB or bootloader.

## 1. Establish the actual board and recovery path

Complete `PORT_CHECKLIST.md`, using the research bundle's hardware and protocol reports. Record the exact silicon ID and measured wiring. Demonstrate physical recovery and preserve calibration/configuration. Downloaded application `.bin` files do not contain a known-good full bootloader backup.

The HPM5300 platform inference is strong, but a confirmed MCU ordering code and a board definition are still required. Do not replace missing board work by selecting an evaluation board.

## 2. Test the new key logic on the development computer

With an existing C11-capable GCC/Clang compiler:

```powershell
python host-tests/run_host_tests.py --compiler clang --build-dir build-host
```

If using a portable Zig compiler as the C compiler:

```powershell
python host-tests/run_host_tests.py --compiler C:\tools\zig\zig.exe --compiler-arg cc --build-dir build-host
```

Tests exercise press/release boundaries, noise within the hysteresis band, full travel sweeps, independent key states, invalid configurations and input saturation. These tests validate the standalone algorithm only. They do not test MCU timing, electrical wiring, USB, calibration or firmware flashing. See `HOST_TEST_RESULTS.md` for the execution status of this supplied snapshot.

## 3. Install/pin the development environment when beginning the hardware port

Follow the [official HPM SDK setup instructions](https://hpm-sdk.readthedocs.io/en/latest/get_started.html) for the confirmed silicon. Use a compatible RISC-V GNU bare-metal compiler and the SDK's required Python dependencies, CMake and Ninja. Pin the SDK commit, toolchain archive hash and dependency versions in your project.

Example environment variables after those tools are installed:

```powershell
$env:HPM_SDK_BASE = 'C:\tools\hpm_sdk'
$env:GNURISCV_TOOLCHAIN_PATH = 'C:\tools\riscv-gnu'
$env:HPM_SDK_TOOLCHAIN_VARIANT = ''
```

The source template uses `find_package(hpm-sdk)`, `sdk_inc` and `sdk_app_src`, following the [official USB keyboard sample](https://github.com/hpmicro/hpm_sdk/blob/main/samples/cherryusb/device/hid/keyboard/CMakeLists.txt). `BOARD_SEARCH_PATH` and `CUSTOM_GCC_LINKER_FILE` come from the [SDK CMake guide](https://hpm-sdk.readthedocs.io/en/latest/cmake_user_guide.html).

## 4. Implement the board layer before compiling a target image

Create the custom board files in `boards/ae64_pro` and implement `port/board_port.c`. The interface is `include/board_port.h`.

- `port_init`: real startup/clock/USB configuration; recovery independent of this application must already work.
- `port_read_calibrated_frame`: actual ADC/mux scan and calibrated travel. Return false for an incomplete or invalid frame; avoid treating sensor faults as keystrokes.
- `port_load_key_configs`: load validated per-key thresholds, with safe defaults defined by the port. Preserve vendor calibration only after its layout and meaning are established.
- `port_publish_keys`: measured logical-to-physical mapping, USB usages and report scheduling.
- `port_usb_service` / `port_fault`: keep transport work timely and signal faults without destructive persistence operations.

Add the confirmed USB implementation and SDK feature flags. The [official CherryUSB HID example](https://github.com/hpmicro/hpm_sdk/tree/main/samples/cherryusb/device/hid/keyboard) is a starting reference for the controller, not a keyboard port. Preserve or deliberately reimplement WebHID device-info/update compatibility if the vendor updater will be used to leave the custom application.

Write and audit `port/ae64_pro.ld`. The recovered vendor code VMA is `0x80021000`, while its transfer container has a separate `0x1000` header. The complete flash partition map and application capacity remain unresolved. Use the actual image layout, section relocation, vectors and protected storage boundaries. Do not copy a full-chip ROM boot header or an evaluation-board flash image into an application update container.

## 5. Compile source to ELF and map

Only after the board layer, startup and linker file are completed:

```powershell
cmake -S . -B build -G Ninja -DBOARD=ae64_pro -DBOARD_SEARCH_PATH="$PWD/boards" -DCUSTOM_GCC_LINKER_FILE="$PWD/port/ae64_pro.ld" -DAE64_BOARD_PORT_READY=ON -DCMAKE_BUILD_TYPE=release
cmake --build build
```

The architecture flags in `CMakeLists.txt` are the baseline `rv32imac_zicsr_zifencei` / `ilp32`. Check the selected silicon, SDK components and resulting instructions before changing extensions or ABI. The template does not guarantee compatibility just because compilation succeeds.

Keep the ELF, map file, compiler versions and build log. Inspect entry point, LOAD addresses, section sizes, stack/heap, copied ILM sections, initialized data and persistent-storage boundaries. Confirm there is no unwanted ROM boot-header or option-byte section.

## 6. Extract the raw application payload

Locate the single intended output ELF; select it explicitly if there are several:

```powershell
$elfFiles = @(Get-ChildItem build -Recurse -Filter ae64_custom.elf)
if ($elfFiles.Count -ne 1) { throw 'Select the intended application ELF explicitly' }
$elfPath = $elfFiles[0].FullName
$toolBin = Join-Path $env:GNURISCV_TOOLCHAIN_PATH 'bin'
& (Join-Path $toolBin 'riscv32-unknown-elf-readelf.exe') -h -l -S $elfPath
& (Join-Path $toolBin 'riscv32-unknown-elf-objcopy.exe') -O binary $elfPath build/app.payload.bin
```

Adjust the tool prefix only to the installed compiler's actual documented prefix. Review the ELF's load memory addresses before accepting this raw output. The result must begin at the intended application entry and contain the startup copy sources; it must not include the separate update header or a huge address hole. Compare its first instructions and layout with the recovered vendor application.

## 7. Package raw payload into the observed update container

Run the bundle's offline container tool from this project directory:

```powershell
python ../../protocol/ae64_container.py pack path/to/original-AE64-Pro.bin build/app.payload.bin build/ae64-custom.container.bin
python ../../protocol/ae64_container.py inspect build/ae64-custom.container.bin
python ../../protocol/ae64_container.py plan build/ae64-custom.container.bin --output build/flash-plan.json
```

Replace `path/to/original-AE64-Pro.bin` with an unchanged original container for board `0030000A`. The tool copies the observed header template and updates the payload length/CRC. It does not grant device compatibility, enforce the unknown flash partition capacity, or prove bootloader acceptance. Its packet plan is offline evidence and sends nothing.

Do a round-trip with an unchanged stock payload first; the reconstructed container should be byte-identical to its original. Next inspect the custom ELF and container together. Keep a known-good original update separately.

## 8. Validate bring-up and then follow the flash guide

The report `../../protocol/FLASH_PROTOCOL.md` describes the actual host update commands and known limits. After hardware recovery, partition boundaries and image compatibility are established, the vendor driver's Local Update path can transfer an application container. Choosing a file is not the same as proving it safe; the update action writes the application.

For the first hardware run, use minimal USB enumeration and a version response with all key output, RGB and persistent writes disabled. Verify recovery. Then enable raw sensor diagnostics, calibration, key conversion and USB output in small stages. Reboot/suspend/wakeup, stuck-key release, malformed HID commands and update recovery need hardware tests. No custom firmware was flashed or hardware functionality demonstrated while preparing this scaffold.
