"""Compile and execute only the new portable key-processing module, no USB/device access."""
import argparse,subprocess,pathlib,os
p=argparse.ArgumentParser();p.add_argument('--compiler',required=True);p.add_argument('--compiler-arg',action='append',default=[]);p.add_argument('--build-dir',type=pathlib.Path,default=pathlib.Path('build-host'))
a=p.parse_args();root=pathlib.Path(__file__).resolve().parents[1];a.build_dir.mkdir(parents=True,exist_ok=True)
out=a.build_dir.resolve()/('test-key-logic.exe' if os.name=='nt' else 'test-key-logic')
cmd=[a.compiler,*a.compiler_arg,'-std=c11','-O2','-Wall','-Wextra','-Werror','-pedantic','-I',str(root/'include'),str(root/'src/key_logic.c'),str(root/'host-tests/test_key_logic.c'),'-o',str(out)]
subprocess.run(cmd,check=True);subprocess.run([str(out)],check=True)
