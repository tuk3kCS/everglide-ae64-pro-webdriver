/* Offline behavioral tests for the new example module. SPDX-License-Identifier: MIT */
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <stdio.h>
#include "key_logic.h"
static void thresholds_and_noise(void) {
    struct ae64_key_config c={5000,4000}; struct ae64_key_state s={false};
    assert(ae64_key_config_valid(&c));
    for (unsigned i=0; i<100; ++i) assert(ae64_key_update(&s,&c,4999)==AE64_NO_CHANGE);
    assert(!s.pressed);
    assert(ae64_key_update(&s,&c,5000)==AE64_PRESSED);
    for (unsigned i=0; i<100; ++i) assert(ae64_key_update(&s,&c,4500)==AE64_NO_CHANGE);
    assert(s.pressed);
    assert(ae64_key_update(&s,&c,4000)==AE64_RELEASED);
    assert(ae64_key_update(&s,&c,4000)==AE64_NO_CHANGE);
}
static void invalid_configs_and_inputs(void) {
    struct ae64_key_state s={true};
    const struct ae64_key_config invalid[]={{0,0},{4000,5000},{10001,1},{10000,10000}};
    for (unsigned i=0;i<sizeof(invalid)/sizeof(invalid[0]);++i) {
        assert(!ae64_key_config_valid(&invalid[i]));
        assert(ae64_key_update(&s,&invalid[i],0)==AE64_NO_CHANGE);
        assert(s.pressed);
    }
    const struct ae64_key_config c={10000,1};
    s.pressed=false;
    assert(ae64_key_update(&s,&c,65535)==AE64_PRESSED);
    assert(ae64_key_update(&s,&c,0)==AE64_RELEASED);
    assert(!ae64_key_config_valid(NULL));
    assert(ae64_key_update(NULL,&c,5000)==AE64_NO_CHANGE);
}
static void independent_keys_and_full_range(void) {
    const struct ae64_key_config c={7500,2500};
    struct ae64_key_state a={false},b={false}; unsigned presses=0,releases=0;
    for (unsigned d=0;d<=10000;++d) presses += ae64_key_update(&a,&c,(uint16_t)d)==AE64_PRESSED;
    assert(presses==1 && a.pressed && !b.pressed);
    for (int d=10000;d>=0;--d) releases += ae64_key_update(&a,&c,(uint16_t)d)==AE64_RELEASED;
    assert(releases==1 && !a.pressed && !b.pressed);
}
int main(void) {
    thresholds_and_noise();invalid_configs_and_inputs();independent_keys_and_full_range();
    puts("PASS: thresholds, hysteresis/noise, independent keys, full travel sweep, invalid input, saturation");
    return 0;
}
