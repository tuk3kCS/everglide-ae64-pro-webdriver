# Custom board definition TODO

Follow the official HPM SDK custom-board layout for the pinned SDK revision. Provide `ae64_pro.yaml`, `board.h`, `board.c`, pin mux source, and required CMake/debug files. The YAML `soc`, `device`, flash capacity and probe fields must come from the actual hardware and confirmed debugger setup. `XS117` is not an established HPM ordering code.

Use `BOARD_SEARCH_PATH` set to the parent `boards` directory. Do not select `hpm5300evk` to make a keyboard build succeed: that substitutes different wiring and recovery assumptions.
