/* Interface to implement after measuring the real board. SPDX-License-Identifier: MIT */
#ifndef AE64_BOARD_PORT_H
#define AE64_BOARD_PORT_H
#include <stdbool.h>
#include <stdint.h>
#include "key_logic.h"
#define AE64_LOGICAL_KEY_COUNT 64u
/* Establish clocks, SRAM/ILM, USB and an independently tested recovery path. */
bool port_init(void);
/* Service USB without waiting for a sample. */
void port_usb_service(void);
/* Return true only for a complete calibrated frame. Never map invalid ADC to a press. */
bool port_read_calibrated_frame(uint16_t travel[AE64_LOGICAL_KEY_COUNT]);
/* Populate per-key thresholds; validate persisted configuration before accepting it. */
bool port_load_key_configs(struct ae64_key_config config[AE64_LOGICAL_KEY_COUNT]);
/* Map logical indices to the measured physical layout and USB HID keycodes. */
void port_publish_keys(const struct ae64_key_state state[AE64_LOGICAL_KEY_COUNT]);
/* Indicate a fault without erasing calibration, reboot looping, or emitting key events. */
void port_fault(void);
#endif
