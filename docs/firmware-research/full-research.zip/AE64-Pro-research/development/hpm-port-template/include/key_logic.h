/* New example logic, not decompiled vendor firmware. SPDX-License-Identifier: MIT */
#ifndef AE64_KEY_LOGIC_H
#define AE64_KEY_LOGIC_H
#include <stdbool.h>
#include <stdint.h>
#define AE64_TRAVEL_MAX 10000u
/* Values are normalized calibrated travel, not millimeters or raw ADC counts. */
struct ae64_key_config { uint16_t press; uint16_t release; };
struct ae64_key_state { bool pressed; };
enum ae64_key_event { AE64_NO_CHANGE=0, AE64_PRESSED=1, AE64_RELEASED=2 };
bool ae64_key_config_valid(const struct ae64_key_config *config);
enum ae64_key_event ae64_key_update(struct ae64_key_state *state,
    const struct ae64_key_config *config, uint16_t calibrated_travel);
#endif
