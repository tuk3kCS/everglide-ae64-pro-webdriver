# Board port intentionally absent

Create `board_port.c` only after completing `../PORT_CHECKLIST.md`. Implement every declaration in `../include/board_port.h` using the confirmed silicon, measured pinout and validated timing.

Supply an application-only linker script as `ae64_pro.ld`; do not copy the stock SDK flash or DFU linker unchanged. The recovered vendor application's code VMA is `0x80021000`; its container has a separate `0x1000` header. Linker symbols, vectors copied to ILM, data initialization, stack/heap bounds and reserved flash must be audited together. These observations do not establish the complete flash map or available application capacity.

No boot header, ROM configuration, option bytes, erase routine, GPIO setup, clock tree, USB IRQ, ADC scan map, calibration layout or recovery shortcut has been invented here.
