# Focused symbol and native-code evidence

These observations were made by parsing and disassembling the five downloaded firmware files. No firmware was executed or flashed. All offsets below refer to the payload, which begins at container offset 0x1000. Add 0x1000 for file offsets.

## Confirmed change: exception-stop diagnostic added in v0.0.6.0

In v0.0.5.0 the matching stop stub at payload +0xFE40 contains only `c.j 0`, an infinite loop. In v0.0.6.0 the corresponding location at payload +0xFE72 now saves registers, passes the incoming first two arguments to a formatting call using `Exception occurred! cause: %ld, epc: %ld\n`, then loops forever. The print-and-stop sequence remains present in v0.0.7.0, v0.0.8.0, and v0.1.0.0. This establishes that diagnostics were added at this stop path. It does not establish a fix to the exception cause or a change to normal keyboard latency. The function name is inferred from context, not an original symbol.

| Version | Stop-routine payload offset | Behavior in decoded instructions |
|---|---|---|
| 0.0.5.0 | 0xfe40 | Infinite loop only |
| 0.0.6.0 | 0xfe72 | Format cause/EPC diagnostic, then infinite loop |
| 0.0.7.0 | 0xffe0 | Format cause/EPC diagnostic, then infinite loop |
| 0.0.8.0 | 0x10488 | Format cause/EPC diagnostic, then infinite loop |
| 0.1.0.0 | 0x1068e | Format cause/EPC diagnostic, then infinite loop |

The complete instruction bytes and format-string cross-references are retained in `confirmed-deltas.json`.

## Confirmed layout change: UART instance wrappers moved in v0.0.6.0

v0.0.5.0 contains eight consecutive 12-byte UART instance stubs at payload +0xBF4 through +0xC54. v0.0.6.0 places the corresponding eight stubs earlier, at payload +0x6F6 through +0x756. Each loads one peripheral base into a0, then tail-calls a common target. The bases are 0xF0040000, 0xF0044000, 0xF0048000, 0xF004C000, 0xF0050000, 0xF0054000, 0xF0058000, and 0xF005C000. These match UART0 through UART7 in the official HPM5361 SoC header. The same sequence remains in v0.0.7.0 and later at +0x6FA through +0x75A. Full-payload scanning confirmed that all eight MMIO-load instructions are present in all five versions. This is a relocation/reordering observation, not evidence of new UART support.

Primary register-map source: https://github.com/hpmicro/hpm_sdk/blob/main/soc/HPM5300/HPM5361/hpm_soc_ip.h (UART base definitions). This supports identification of the wrappers as UART instance wrappers; it does not prove the exact MCU package, which UART is routed to board pins, whether diagnostics are externally accessible, or any UART behavior change.

## Embedded names are not a symbol table

Each firmware has 78 code cross-references to function-like strings, mostly RT-Thread assertion names, with a stable name set. Examples include rt_thread_init, rt_thread_suspend, main_thread_entry, and sub_thread_entry. These are useful semantic anchors. They are not ELF symbols and do not automatically give exact function entry addresses. The per-version `*-named-candidates.json` files preserve preceding direct-call-target intervals and nearby prologue candidates as separate fields. In particular, a name can occur in an assertion tail block, so the closest direct-call target can be an internal block rather than the full function entry.

No claim is made that the RT-Thread implementation is globally identical across versions solely because these names are unchanged. The firmware is stripped, contains code/data mixtures and likely multiple execution regions, and this focused analysis is not a complete decompilation.

## Reproduction

Use the original files under `../..` sibling `AE64-Pro-firmware`, or the archive delivered earlier. Parent analysis outputs `analysis/*-disassembly.txt` and `analysis/*-string-xrefs.json` contain full instruction/text references. The supplied `confirmed-deltas.json` anchors each finding to exact file bytes, so a separate tool can verify the claims without relying on inferred names.
