# Independent review of recovered changes

This review cross-checked the protocol investigator's claims against the saved native instruction excerpts, the five original payloads, and the shipped JavaScript field decoder. It is static review; no keyboard was modified and no behavior was measured on hardware.

## Review result

| Release | Claim | Result and exact boundary |
|---|---|---|
| 0.0.6.0 | Configuration switch emits additional profile-specific state flags | Supported. In `02 03`, when an accepted profile actually changes, the new block updates the second flag word at RAM 0x8D174. Mapping is profile 0 -> 0x08, profile 1 -> 0x10, profile 2 -> 0x20, profile 3 -> 0x40. A downstream user-visible fix has not been established. |
| 0.0.7.0 | Axis-ID changes clear calibration status | Supported with the field-name qualification below. In `04 02`, the validated changed axis ID store at payload 0xC890 is followed by `sb zero, 8(a2)` at 0xC894. In the prior version the matching ID-change path stores the ID and dirty flags without that byte clear. |
| 0.0.8.0 | Per-key mode values are validated | Supported. In `04 02`, payload 0xC93A loads request byte 4, 0xC942 loads limit 2, 0xC944 admits values <=2, and 0xC948..0xC94E writes error FF in response byte 4 and exits for larger values. |
| 0.0.8.0 | Per-key mode change clears runtime state | Supported as a specific bit reset. The handler compares the previous mode to the accepted new mode at 0xC978..0xC97C; on a difference, it loads the per-key runtime halfword at 0xC99C, applies AND -5 at 0xC9A0, and stores it at 0xC9A2. That clears bit mask 0x0004. The bit's exact higher-level meaning is unassigned. |
| 0.0.8.0 | Shake optimization is mirrored into configuration state | Supported. In `02 10` (hex 10, decimal 16), 0xBCAA..0xBCB0 extracts runtime bit 11; 0xBCB4 writes its boolean value to RAM 0x82B69; 0xBCB8..0xBCC8 ORs 0x08 into flag word RAM 0x8D284. Previous v0.0.7.0 changes the runtime bit and response, without that configuration mirror/flag block. Save handling is plausible, but reboot persistence is not proved by this excerpt alone. |

## Axis-ID reset: what is and is not established

The driver maps request bytes 21..22 to `axisV2Id` and response byte 20 to `calibrate`. The native handler's per-key record byte +8 is subsequently copied to response byte 20 at v0.0.7.0 payload 0xC9AE/0xC9BA. This supports calling the cleared byte a calibration/status byte and supports the phrase "changing a validated axis ID invalidates its prior calibration status." It does not prove that the handler immediately performs a full ADC recalibration or that sensor accuracy or latency improves.

The relevant source text is in `work/index-D-Vi6Arc.js`, `setPerformance` and `getPerformanceData`. The native evidence is `protocol/native-handler-excerpts/0.0.6.0-family04-cmd02.txt` and `0.0.7.0-family04-cmd02.txt`.

## Configuration flag mapping correction

The first protocol report draft swapped profile 0 and profile 1. Independent branch tracing gives:

- At v0.0.6.0 0xC228, compare selected profile to register a4, which holds subcommand 2; equal jumps to OR 0x20.
- At 0xC22C, compare to a6, which holds 3; equal jumps to OR 0x40.
- At 0xC230, compare to a0, which holds 1; equal jumps to OR 0x10.
- Remaining accepted profile 0 takes the fallthrough OR 0x08 at 0xC234.

The protocol investigator was notified to apply the correction. Offsets in the table above are independently checked against instruction bytes rather than copied from the draft prose.

## Independent HID report descriptor parse

The separate `hid-descriptor-review.json` records a short-item HID parser applied directly to the first shared keyboard Report ID 1 descriptor in each original payload. The results are:

| Version | Shared keyboard descriptor bytes | Input fields, excluding report ID | Output fields, excluding report ID |
|---|---:|---|---|
| 0.0.5.0 | 25 | 120 one-bit data fields, Keyboard usages 0x04..0x70 | None in this collection |
| 0.0.6.0 | 25 | Same | None in this collection |
| 0.0.7.0 | 25 | Same | None in this collection |
| 0.0.8.0 | 45 | Same 120 input bits | LED usage page 0x08, usages 1..3: 3 data bits plus 5 constant padding bits |
| 0.1.0.0 | 57 | 109 key bits for usages 0x04..0x70, 11 constant padding bits, 8 explicit modifier bits for usages 0xE0..0xE7; total 128 bits | Same 8-bit LED output report |

Consequently, the described shared Report ID 1 input is 15 payload bytes before v0.1.0.0 and 16 payload bytes in v0.1.0.0, or 16 and 17 bytes respectively when including its report-ID byte. This is a concrete host-facing descriptor layout change. Successful host/keyboard runtime interaction with the changed layout has not been tested here.

The standard separate boot-keyboard descriptor already includes LED outputs in the older images. The v0.0.8.0 claim must therefore say that it adds LED outputs to the shared/NKRO Report ID 1 collection, not that the keyboard acquired lock-LED support for the first time. LED usages 1..3 identify Num Lock, Caps Lock, and Scroll Lock.

The 11 padding bits in the newest descriptor are declared constant; treating them as 11 additional supported keys would be incorrect. The full set of 120 earlier data bits also should not be described as a physical 120-key matrix: the usages named by that collection span only 109 values, and the board's physical key layout is a separate matter.
