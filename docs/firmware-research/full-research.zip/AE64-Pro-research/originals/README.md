# AE64 Pro firmware archive

Extracted on October 28, 2026 from https://www.xsyd.top/v2-app.

Device: AE64 Pro; USB VID:PID 1CA6:300A; board ID 0030000A; product C048P010; chip XS117.
The connected keyboard reported installed version v0.0.7.0. Only the device-information command was used; no firmware was flashed and no settings were changed.

## Included firmware

| Version | Firmware date | File size (bytes) | Original filename |
| --- | --- | ---: | --- |
| v0.1.0.0 | 2026-09-30 | 118,776 | XS117_C048P010_AE64Pro_App_v0.1.0.0_20260930a.bin |
| v0.0.8.0 | 2026-09-01 | 118,232 | XS117_C048P010_AE64Pro_App_v0.0.8.0_20260901a.bin |
| v0.0.7.0 | 2026-06-25 | 116,992 | XS117_C048P010_AE64Pro_App_v0.0.7.0_20260625a.bin |
| v0.0.6.0 | 2026-05-19 | 116,608 | XS117_C048P010_AE64Pro_App_v0.0.6.0_20260519a.bin |
| v0.0.5.0 | 2026-03-05 | 116,464 | XS117_C048P010_AE64Pro_App_v0.0.5.0_20260305a.bin |

The server selected v0.1.0.0 as latest. Firmware dates are taken from the server firmware_time field; upload timestamps are retained separately in manifest.json and server-response.json.

## Scope and verification

This archive contains all five entries returned in the driver firmware-history array for this exact board and USB ID on the retrieval date. The current-firmware and latest-firmware entries duplicate v0.1.0.0. Earlier releases not exposed by that history list, removed files, or unpublished versions cannot be established from this result.

The .bin downloads are unchanged original files. Each has the same firmware header signature and board ID 0030000A, and its declared payload size matches the downloaded length. All five stored CRC-32 checksums match their firmware payloads. SHA256SUMS.txt provides independently computed hashes. The manifest records source download URLs, sizes, HTTP metadata, original catalog fields, and header checks.

Source catalog endpoint: https://api.sparklinkplayjoy.com/api/v1/getKeyboardFirmware?board_id=0030000a&vid=1ca6&pid=300a

The application requests that endpoint with board_id, vid, and pid. Its history selector uses the returned firmwares array. Files are downloaded through the same-origin /storage/ paths, matching the driver URL rewriting.

Included metadata: manifest.json, server-response.json, SHA256SUMS.txt.
