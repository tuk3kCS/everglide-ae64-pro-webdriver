# AE64 Pro firmware research bundle

Start with [reconstructed changes](CHANGELOG_RECONSTRUCTED.md), then [the custom-firmware pipeline](DEVELOPMENT_PIPELINE.md).

This bundle covers all five original AE64 Pro firmware images for board `0030000A`. It contains a static analysis and development workbench, not a complete flash-ready replacement firmware. No update, boot transition or custom firmware write was sent to the keyboard while preparing it.

## Contents

- `originals/`: unchanged manufacturer application containers and the original server manifest.
- `CHANGELOG_RECONSTRUCTED.md`: supported differences, with inference/coverage limits.
- `DEVELOPMENT_PIPELINE.md`: source, board port, compile, package and eventual flash procedure.
- `analysis/`: header inventory, strings, RV32 linear disassembly, HID fields and candidate-region diffs.
- `protocol/`: wire format, container tool, packet plans, exact vendor-code snippets, native command maps and tests.
- `hardware/`: HPM platform evidence, primary-source snapshots and reconstructed startup memory maps.
- `symbols/`: assertion-name anchors, focused native deltas and independent review.
- `development/hpm-port-template/`: unfinished board scaffold and a tested new C hysteresis module.
- `tools/`: portable inventory/descriptor/disassembly reproducer and pinned optional Capstone dependency.
- `VALIDATION.md`: checks actually executed and their limits.

## Repeat the offline checks

From this extracted folder:

```powershell
python protocol/test_offline.py originals
python tools/verify_evidence.py
python tools/analyze_firmware.py originals build/reproduced
```

For optional disassembly, install the pinned dependency in a virtual environment first:

```powershell
python -m venv build/analysis-env
build/analysis-env/Scripts/python.exe -m pip install -r tools/requirements.txt
build/analysis-env/Scripts/python.exe tools/analyze_firmware.py originals build/reproduced-disassembly --disassemble
```

The files under `analysis/` are evidence artifacts. Descriptor-only `.bin` files and extracted payloads are not complete update containers. The experimental region matcher masks relocations and call targets and uses heuristic boundaries; its counts are not exact counts of changed functions or proven equivalent behavior.

The earlier web-application REA Evidence record is cited with its original scope in the reports. Native findings use direct byte/disassembly evidence because no native decompiler provider was available; none are presented as recovered original source or hardware execution.
